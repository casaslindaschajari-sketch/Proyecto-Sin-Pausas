# Paquete descargable · Proyecto Sin Pausas

Este paquete contiene todo lo necesario para subir manualmente el MVP Sabrina AI Lab a GitHub.

## Contenido

```text
github_copy_package/
├── README_DESCARGA.md
├── COPY_MANIFEST_FOR_GITHUB.md
├── COPY_PASTE_TO_GITHUB.md
├── GITHUB_UPLOAD_INSTRUCTIONS_FOR_COPILOT.md
├── copy_chunks/
│   ├── COPY_01_ROOT_README.md
│   ├── COPY_02_GITIGNORE.md
│   ├── COPY_03_SABRINA_AI_LAB_README.md
│   └── COPY_04_APP_PY_PART_01_OF_05.md ... COPY_04_APP_PY_PART_05_OF_05.md
└── project/
    ├── README.md
    ├── .gitignore
    └── proyectos/
        └── sabrina_ai_lab/
            ├── README.md
            └── app.py
```

## Qué usar

### Opción recomendada

Sube directamente el contenido de la carpeta:

```text
project/
```

Esa carpeta ya tiene la estructura correcta para GitHub.

### Opción manual por copiar y pegar

Usa:

```text
COPY_MANIFEST_FOR_GITHUB.md
```

y luego copia los archivos dentro de:

```text
copy_chunks/
```

### Opción todo en un solo documento

Usa:

```text
COPY_PASTE_TO_GITHUB.md
```

Ese archivo contiene todo junto, incluyendo el código completo de `app.py`.

## Repositorio objetivo

```text
https://github.com/casaslindaschajari-sketch/Proyecto-Sin-Pausas
```

## Ejecutar la app

Después de descargar/subir el proyecto:

```bash
python3 proyectos/sabrina_ai_lab/app.py
```

Abrir:

```text
http://127.0.0.1:8000
```

## Seguridad

No subas:

```text
.env
claves Azure
tokens GitHub
llaves SSH privadas
bases SQLite runtime
.vscode-server/
__pycache__/
cache folders
```
